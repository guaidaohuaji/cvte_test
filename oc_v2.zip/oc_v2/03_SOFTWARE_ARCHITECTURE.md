# 软件架构、初始化顺序与数据流

## 1. `main.c`初始化顺序

真实源码顺序：

```c
MX_GPIO_Init();
MX_DMA_Init();
MX_USART1_UART_Init();
MX_USART6_UART_Init();
MX_TIM4_Init();
MX_TIM1_Init();
MX_ADC1_Init();
MX_TIM10_Init();
MX_TIM2_Init();

AppUart_Init();
AppOneWireUart_Init();
AppOneWire_Init();
AppLed_Init();
AppPwm_Init();
AppPwmInput_Init();
AppNtc_Init();
AppFan_Init();
AppAdcScan_Init();
```

其中：

- `AppPwm_Init()`失败会进入`Error_Handler()`；
- `AppPwmInput_Init()`失败会进入`Error_Handler()`；
- `AppNtc_Init()`、`AppFan_Init()`、`AppAdcScan_Init()`返回值被忽略；
- 后三者的失败需要通过状态查询或调试变量判断。

## 2. 主循环顺序

```c
AppUart_Process();
AppOneWireUart_Process();
AppOneWire_Process();
AppLed_Process();
AppPwmInput_Process();
AppNtc_Process();
AppFan_Process();
AppAdcScan_Process();
AppFanFeedback_Process();
```

影响：

- W2控制先于业务状态机；
- LED使用本轮最新单总线状态；
- NTC和Fan在本轮读取的是此前已整理的数据；
- ADC扫描整理和风机反馈处理位于循环尾部，通常造成一个主循环级延迟；
- 所有业务都必须保持非阻塞。

## 3. 中断与回调

### UART

`main.c`集中定义：

```text
HAL_UART_RxCpltCallback
HAL_UART_TxCpltCallback
HAL_UART_ErrorCallback
```

### PWM输入

`main.c`：

```text
HAL_TIM_IC_CaptureCallback -> AppPwmInput_CC_Callback
HAL_TIM_PeriodElapsedCallback -> AppPwmInput_UP_Callback
```

### ADC DMA

`app_adc_scan.c`直接定义：

```text
HAL_ADC_ConvHalfCpltCallback
HAL_ADC_ConvCpltCallback
```

后续不得在其他文件重复定义这些HAL回调。

## 4. 应用数据流

### 通用PWM输出

```text
USART1对象0x01
→ AppPwm_SetFrequency
→ AppPwm_SetDutyX100
→ AppPwm_Enable
→ TIM4_CH1 / PB6
```

### PWM输入

```text
PE9 / TIM1_CH1双边沿
→ TIM1_CC和UPDATE中断
→ AppPwmInput原始捕获
→ AppPwmInput_Process
→ 对象0x03快照
```

### 风机控制

```text
USART1对象0x06
→ AppFan_SetEnabled
→ 启动boost/目标占空比状态机
→ TIM10_CH1 / PB8
```

### 风机反馈

```text
PA0 ADC1_IN0
→ ADC1 DMA交错缓冲
→ AppAdcScan_GetCh0Block
→ 移动平均+双阈值+边沿确认
→ 频率
→ AppFan换算RPM
→ 对象0x06快照
```

### NTC

```text
PB1 ADC1_IN9
→ ADC1 DMA交错缓冲
→ AppAdcScan_GetNtcAverage
→ 电压/电阻/B参数温度
→ 对象0x05快照
```

## 5. 模块职责

### `app_adc_scan.c`

- 启动ADC1 DMA；
- 启动TIM2；
- 管理1024 halfword循环缓冲；
- 累加rank2 NTC样本；
- 向风机反馈提供rank1缓冲；
- 记录overrun。

### `app_pwm.c`

- TIM4动态频率参数计算；
- 频率1～100000 Hz；
- 占空比0～10000；
- 返回实际频率、误差ppm、PSC/ARR/CCR。

### `app_pwm_input.c`

- TIM1 1 MHz扩展时间戳；
- 双边沿捕获；
- 过捕获恢复；
- 静态电平和超时识别；
- 返回频率mHz、占空比x100和age。

### `app_fan.c`

- TIM10风机PWM；
- 启动boost；
- 目标/实际占空比；
- 风机状态；
- 无测速超时；
- RPM快照。

### `app_fan_feedback_adc.c`

- 对PA0 ADC数据做10点移动平均；
- 高低双阈值；
- 最小持续样本确认；
- 周期范围过滤；
- 连续3个好周期后发布频率。

### `app_ntc.c`

- 读取共享ADC平均；
- 计算ADC电压；
- 按当前分压模型计算电阻；
- B参数计算温度；
- 0～60°C窗口分类。

### `app_uart.c`

- USART1 128字节ring；
- W2解析；
- 对象`0x01~0x08`；
- 50 ms帧超时；
- 阻塞式短帧回复`HAL_UART_Transmit(...,100ms)`。

## 6. 架构保护原则

- 不在中断里做浮点温度计算或完整协议状态机；
- 不把ADC1拆成两个互相竞争的启动流程；
- 不让风机反馈和NTC分别调用`HAL_ADC_Start*`；
- 不重复定义ADC/TIM/UART回调；
- 不使用`HAL_Delay()`处理通信或采样；
- 修改共享ADC时必须同时评估风机反馈和NTC。
