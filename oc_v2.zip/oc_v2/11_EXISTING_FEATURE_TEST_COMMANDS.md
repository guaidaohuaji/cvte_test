# 既有功能串口测试命令

设置：

```text
USART1
9600
8N1
HEX
不加回车换行
```

## 1. 查询

```text
PWM输出: 7E A1 03 01 A5
LED:     7E A1 03 02 A6
PWM输入: 7E A1 03 03 A7
PD13:    7E A1 03 04 A8
NTC:     7E A1 03 05 A9
风机:    7E A1 03 06 AA
单总线:  7E A1 03 08 AC
```

## 2. 通用PWM输出

### 1 kHz、50.00%、enable

```text
7E A2 0A 01 01 E8 03 00 00 88 13 34
```

成功响应：

```text
7E A2 04 00 01 A7
```

PB6预期：

```text
约1 kHz
约50%
```

### disable

```text
7E A2 0A 01 00 00 00 00 00 00 00 AD
```

成功响应同上。PB6应保持非激活电平。

## 3. LED

```text
手动灭: 7E A2 04 02 00 A8
手动亮: 7E A2 04 02 01 A9
自动:   7E A2 04 02 02 AA
```

成功响应：

```text
7E A2 04 00 02 A8
```

## 4. PD13

```text
低: 7E A2 04 04 00 AA
高: 7E A2 04 04 01 AB
```

成功响应：

```text
7E A2 04 00 04 AA
```

随后查询：

```text
7E A1 03 04 A8
```

## 5. 风机

### 100%

```text
7E A2 06 06 01 10 27 E6
```

成功响应：

```text
7E A2 04 00 06 AC
```

预期：

```text
立即STARTUP_BOOST
PB8约10 kHz/100%
2秒后仍为100%
有反馈时RUNNING
```

### 50%

```text
7E A2 06 06 01 88 13 4A
```

首次enable时仍先100% boost 2 s，之后50%。

### disable

```text
7E A2 06 06 00 00 00 AE
```

成功响应：

```text
7E A2 04 00 06 AC
```

## 6. PWM输入建议测试矩阵

信号源接PE9，共地。

| 输入 | 期望 |
|---|---|
| 1 kHz, 50% | 频率约1,000,000 mHz；占空比约5000 |
| 1 kHz, 25% | 用于确认是否报告2500或7500 |
| 1 kHz, 75% | 用于确认是否报告7500或2500 |
| 10 Hz | 范围下部 |
| 5 kHz | 范围上部 |
| 静态高 >2.5 s | STATIC_HIGH |
| 静态低 >2.5 s | STATIC_LOW |

25%和75%是确认当前占空比方向的关键用例。

## 7. NTC建议测试

查询：

```text
7E A1 03 05 A9
```

记录：

```text
state
adc_raw
voltage_mv
resistance_ohm
temp_centi_c
age_ms
```

至少使用三个已知点：

- 低温/高阻；
- 中间点；
- 高温/低阻。

不要仅凭`state=OK`判断准确。

## 8. 风机反馈建议测试

查询：

```text
7E A1 03 06 AA
```

记录：

```text
fan_state
target duty
applied duty
FG frequency
RPM
tach age
```

使用示波器同时观察：

- PB8风机PWM；
- PA0反馈电压；
- 实际转速仪。

验证：

```text
RPM ≈ FG_Hz × 30
```

若风机不是2脉冲/转，该公式会错误。

## 9. 只读对象控制

对对象0x03和0x05发送A2，应返回READ_ONLY：

```text
status=07
```

不要把查询帧当作控制帧。
